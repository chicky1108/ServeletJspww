
package com.cg.banking.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServiceDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;

@WebServlet(urlPatterns="/fundTransfer",loadOnStartup=1)
public class FundTransferServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private BankingServices services;

	@Override
	public void init() throws ServletException {
		services=new BankingServicesImpl();

	}
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int accountNoTo = Integer.parseInt(request.getParameter("accountNoTo"));
		int accountNoFrom = Integer.parseInt(request.getParameter("accountNoFrom"));
		float transferAmount = Float.parseFloat(request.getParameter("transferAmount"));
		int pinNumber = Integer.parseInt(request.getParameter("pinNumber"));
		try {
			boolean fundTransfer = services.fundTransfer(accountNoTo, accountNoFrom, transferAmount, pinNumber);
			request.setAttribute("fundTransfer", fundTransfer);
			request.getRequestDispatcher("fundTransferSuccess.jsp").forward(request, response);
		}
		catch (InsufficientAmountException e) 
		{
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("fundTransfer.jsp").forward(request, response);
		}
		catch (AccountNotFoundException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("fundTransfer.jsp").forward(request, response);
		} catch (InvalidPinNumberException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("fundTransfer.jsp").forward(request, response);
		} catch (BankingServiceDownException e) {

		} catch (AccountBlockedException e) {
			request.setAttribute("error", e.getMessage());
			request.getRequestDispatcher("fundTransfer.jsp").forward(request, response);
		}
    }
    public void destroy() {
    	services = null;
	}
}
